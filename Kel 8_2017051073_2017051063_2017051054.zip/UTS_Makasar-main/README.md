# UTS_Makasar
(Matematika Dasar)

2017051063 Arya Affanda Auliya Duha
2017051073 Muhammad Dzaki Arrahman
2017051054 Fachri Azka Nur

