package com.example.abc;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import com.example.abc.databinding.BangundatarlkBinding;
import com.example.abc.databinding.FragmentOperationBinding;

public class LKBangunDatar extends Fragment implements View.OnClickListener{

    private BangundatarlkBinding blk;
    private Button psg, pp, sgt;
    Double bil1, bil2, bil3;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        blk = BangundatarlkBinding.inflate(inflater, container, false);
        View root = blk.getRoot();

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        blk.psg.setOnClickListener(this);
        blk.pp.setOnClickListener(this);
        blk.sgt.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Result result = new Result();
        FragmentManager fragmentManager = getParentFragmentManager();
        bil1 = getArguments().getDouble("a1");
        bil2 = getArguments().getDouble("a2");
        bil3 = getArguments().getDouble("a3");
        Bundle bundle = new Bundle();
        bundle.putDouble("a1", bil1);
        bundle.putDouble("a2", bil2);
        bundle.putDouble("a3", bil3);
        if(view.getId() == R.id.psg){
            bundle.putInt("operation", 0);
        }else if(view.getId() == R.id.pp){
            bundle.putInt("operation", 1);
        }else if(view.getId() == R.id.sgt){
            bundle.putInt("operation", 2);
        }else{
            Toast.makeText(getContext(), "error", Toast.LENGTH_SHORT).show();
        }
        result.setArguments(bundle);
        fragmentManager
                .beginTransaction()
                .replace(R.id.nav_host_fragment_activity_main, result, Result.class.getSimpleName())
                .addToBackStack(null)
                .commit();
    }

}
