package com.example.abc;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.abc.databinding.FragmentResultBinding;
import com.example.abc.ui.dashboard.DashboardFragment;


public class Result extends Fragment implements View.OnClickListener{
    private FragmentResultBinding binding;
    private Button btnAwal;
    Double a1, a2, a3, result;
    Integer i;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentResultBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.backtodashboard.setOnClickListener(this);

        a1 = getArguments().getDouble("a1");
        a2 = getArguments().getDouble("a2");
        a3 = getArguments().getDouble("a3");
        i = getArguments().getInt("operation");

        if(i == 0){
            result = a1 * a2;
        }else if(i == 1){
            result = a1 * a2;
        }else if(i == 2){
            result = a1 * a2 /a3;
        }

        binding.hasil.setText(Double.toString(result));
    }

    @Override
    public void onClick(View view) {
        FragmentManager fragmentManager = getParentFragmentManager();
        DashboardFragment dashboardFragment = new DashboardFragment();
        if(view.getId() == R.id.backtodashboard){
            fragmentManager
                    .beginTransaction()
                    .replace(R.id.nav_host_fragment_activity_main, dashboardFragment, DashboardFragment.class.getSimpleName())
                    .addToBackStack(null)
                    .commit();
        }
    }

}
