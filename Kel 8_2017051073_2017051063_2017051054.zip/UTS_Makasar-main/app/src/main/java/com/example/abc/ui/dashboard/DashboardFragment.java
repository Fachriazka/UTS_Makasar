package com.example.abc.ui.dashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;

import com.example.abc.LKBangunDatar;
import com.example.abc.OperationFragment;
import com.example.abc.R;
import com.example.abc.databinding.FragmentDashboardBinding;
import com.example.abc.databinding.FragmentHomeBinding;
import com.example.abc.ui.home.HomeViewModel;

public class DashboardFragment extends Fragment implements View.OnClickListener{

    private FragmentDashboardBinding binding;
    private EditText panjang,lebar,tingi;
    private Button pilih;
    Double a1,a2,a3;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textAwal;
        homeViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);

        panjang = binding.panjang;
        lebar = binding.lebar;
        tingi = binding.tingi;

        return root;
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.pilih.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.pilih){
            LKBangunDatar lkBangunDatar = new LKBangunDatar();
            FragmentManager fragmentManager = getParentFragmentManager();
            a1 = Double.parseDouble(panjang.getText().toString().trim());
            a2 = Double.parseDouble(lebar.getText().toString().trim());
            a3 = Double.parseDouble(tingi.getText().toString().trim());
            Bundle bundle = new Bundle();
            bundle.putDouble("a1", a1);
            bundle.putDouble("a2", a2);
            bundle.putDouble("a3", a3);
            lkBangunDatar.setArguments(bundle);
//            Log.e("bundle", String.valueOf(getArguments().getDouble("a1")));
            fragmentManager
                    .beginTransaction()
                    .replace(R.id.nav_host_fragment_activity_main, lkBangunDatar, LKBangunDatar.class.getSimpleName())
                    .addToBackStack(null)
                    .commit();
        }else{
            Toast.makeText(getContext(), "error", Toast.LENGTH_SHORT).show();
        }
    }
    // original
//    private FragmentDashboardBinding binding;
//
//    public View onCreateView(@NonNull LayoutInflater inflater,
//                             ViewGroup container, Bundle savedInstanceState) {
//        DashboardViewModel dashboardViewModel =
//                new ViewModelProvider(this).get(DashboardViewModel.class);
//
//        binding = FragmentDashboardBinding.inflate(inflater, container, false);
//        View root = binding.getRoot();
//
//        final TextView textView = binding.textAwal;
//        dashboardViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
//        return root;
//    }
//
//    @Override
//    public void onDestroyView() {
//        super.onDestroyView();
//        binding = null;
//    }
}